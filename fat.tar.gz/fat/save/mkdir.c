#include    "fs.h"

int       add_dir(int fd, t_dir dir, const char *pathname)
{
  do
  {
    if (read(fd, &dir, sizeof(dir)) == sizeof(dir))
    {
      if (dir.next_dir != 0)
        lseek(fd, -sizeof(dir) + dir.next_dir, SEEK_CUR);
    }
    else
    {
      lseek(fd, sizeof(t_hd), SEEK_SET);
      memcpy(&dir.pathname[0], pathname, strlen(pathname));
      dir.next_dir = 0;
      dir.first_file = 0;
      write(fd, &dir, sizeof(dir));
      return (EXIT_SUCCESS);
    }
  }
  while (dir.next_dir != 0);
  dir.next_dir = sizeof(dir);
  lseek(fd, -sizeof(dir), SEEK_CUR);
  write(fd, &dir, sizeof(dir));
  bzero(dir.pathname, 64);
  memcpy(&dir.pathname[0], pathname, strlen(pathname));
  dir.next_dir = 0;
  dir.first_file = 0;
  write(fd, &dir, sizeof(dir));
}

int       my_mkdir(const char *pathname, mode_t mode, int fd)
{
  t_dir   dir;
  char    **tmp;
  int     i;

  bzero(dir.pathname, 64);
  lseek(fd, sizeof(t_hd), SEEK_SET);
  tmp = my_str_to_wordtab(pathname, SLASH);
  i = 0;
  if (tablen(tmp) == 1)
    add_dir(fd, dir, pathname);
  else
    while (tmp[i + 1])
    {
      puts(tmp[i]);
      i++;
    }
}