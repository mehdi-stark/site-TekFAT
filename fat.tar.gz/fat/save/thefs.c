// Jason Brillante "Damdoshi"
// Hanged Bunny Studio 2014-2015
//
// 

#include		<string.h>
#include		<stdlib.h>
#include		<unistd.h>
#include		<fcntl.h>
#include		<stdio.h>

typedef struct		s_dir
{
  char			      name[64];
  int			        next_dir;
  int			        first_file;
}			            t_dir;

int       my_mkdir(const char *pathname, mode_t mode, int fd)
{
  t_dir   dir;

  bzero(dir.name, 64);
  lseek(fd, 0, SEEK_SET);
  do
  {
    if (read(fd, &dir, sizeof(dir)) == sizeof(dir))
    {
      if (dir.next_dir != 0)
        lseek(fd, -sizeof(dir) + dir.next_dir, SEEK_CUR);
    }
    else
    {
      lseek(fd, 0, SEEK_SET);
      memcpy(&dir.name[0], pathname, strlen(pathname));
      dir.next_dir = 0;
      dir.first_file = 0;
      write(fd, &dir, sizeof(dir));
      return (EXIT_SUCCESS);
    }
  }
  while (dir.next_dir != 0);
  dir.next_dir = sizeof(dir);
  lseek(fd, -sizeof(dir), SEEK_CUR);
  write(fd, &dir, sizeof(dir));
  bzero(dir.name, 64);
  memcpy(&dir.name[0], pathname, strlen(pathname));
  dir.next_dir = 0;
  dir.first_file = 0;
  write(fd, &dir, sizeof(dir));
}

int			main(int		argc,
			     char		**argv)
{
  t_dir			dir;
  int			fd;
  int			c;

  fd = open("my_hard_drive", O_RDWR | O_CREAT, 0644);
  if (argc == 2 && strcmp(argv[1], "ls") == 0)
    while ((c = read(fd, &dir, sizeof(dir))) == sizeof(dir))
    {
      printf("%s\n", &dir.name[0]);
	    if (dir.next_dir != 0)
	     lseek(fd, -sizeof(dir) + dir.next_dir, SEEK_CUR);
	    else
	    {
        close(fd);
	      return (EXIT_SUCCESS);
	    }
    }
  else {
    my_mkdir("zizi", 0, fd);
    my_mkdir("caca", 0, fd);
  }
  close(fd);
  return (EXIT_SUCCESS);
}

int      firstdir(t_dir *dir, char *pathname, int fd) 
{
  lseek(fd, sizeof(hd), SEEK_SET);
  if (read(fd, dir, sizeof(*dir)) != sizeof(*dir))
  {
    lseek(fd, sizeof(hd), SEEK_SET);
    memcpy(&dir->pathname[0], pathname, strlen(pathname));
    dir->next_dir = 0;
    dir->first_file = 0;
    dir->sub_dir = 0;
    write(fd, dir, sizeof(*dir));
    return (1);
  }
  return (0);
}

int      subdir(char *pathname, t_dir *dir, int *fd)
{
  char   **tmp;
  char   **tmp2;
  int    i;
  int    c;

  i = 0;
  tmp = my_str_to_wordtab(pathname, slash);
  if (tmp[i + 1] == NULL) 
  {
    do
    {
      lseek(*fd, sizeof(t_hd), SEEK_SET);
      if (read(*fd, dir, sizeof(*dir)) == sizeof(*dir))
      {
        if (dir->next_dir != 0)
          lseek(*fd, -sizeof(*dir) + dir->next_dir, SEEK_CUR);
      }
      else
      {
        lseek(*fd, 0, SEEK_SET);
        memcpy(&dir->pathname[0], pathname, strlen(pathname));
        dir->next_dir = 0;
        dir->first_file = 0;
        write(*fd, dir, sizeof(*dir));
        return (EXIT_SUCCESS);
      }
    }
      while (dir->next_dir != 0);
      dir->next_dir = sizeof(*dir);
      lseek(*fd, -sizeof(*dir), SEEK_CUR);
      write(*fd, dir, sizeof(*dir));
      memcpy(&dir->pathname[0], pathname, strlen(pathname));
      dir->next_dir = 0;
      dir->first_file = 0;
      write(*fd, dir, sizeof(*dir));
  }
  else {
    while (tmp[i + 1])
    {
    c = 0;
    while (dir->next_dir != 0)
    { 
      lseek(*fd, -sizeof(*dir) + dir->next_dir, SEEK_CUR);
      read(*fd, dir, sizeof(*dir));
      tmp2 = my_str_to_wordtab(dir->pathname, slash);
      if (strcmp(tmp2[tablen(tmp2) - 1], tmp[i]) == 0)
      {
        lseek(*fd, -sizeof(*dir) + dir->sub_dir, SEEK_CUR);
        read(*fd, dir, sizeof(*dir));
        c = i;
        break;
      }
      free_tab(tmp2);
    }
    if (c == 0)
    {
      puts("Path incorrect");
      return (-1);
    }
    i++;
    }
  }
  
  free_tab(tmp);
}