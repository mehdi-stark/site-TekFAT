#include    "fs.h"


int       mk(const char *pathname, mode_t mode, int fd)
{
  t_dir   dir;
  int     c;

  if (read(fd, &dir, sizeof(dir)) == sizeof(dir))
    {
      c = lseek(fd, 0, SEEK_END);
     /* dir.next_dir = sizeof(dir);
      lseek(fd, -sizeof(dir), SEEK_CUR);
      write(fd, &dir, sizeof(dir));
      bzero(dir.pathname, 64);
      memcpy(&dir.pathname[0], pathname, strlen(pathname));
      dir.next_dir = 0;
      dir.first_file = 0;*/
      bzero(dir.pathname, 64);
      memcpy(&dir.pathname[0], pathname, strlen(pathname));
      write(fd, &dir, sizeof(dir));
    }
  else
    {
      lseek(fd, sizeof(t_hd), SEEK_SET);
      bzero(dir.pathname, 64);
      memcpy(&dir.pathname[0], pathname, strlen(pathname));
      dir.next_dir = 0;
      dir.first_file = 0;
      write(fd, &dir, sizeof(dir));
    }
}

int       add_dir(int fd, t_dir dir, const char *pathname)
{
  do
  {
    if (read(fd, &dir, sizeof(dir)) == sizeof(dir))
    {
      if (dir.next_dir != 0)
        lseek(fd, -sizeof(dir) + dir.next_dir, SEEK_CUR);
    }
    else
    {
      lseek(fd, sizeof(t_hd), SEEK_SET);
      memcpy(&dir.pathname[0], pathname, strlen(pathname));
      dir.next_dir = 0;
      dir.first_file = 0;
      write(fd, &dir, sizeof(dir));
      return (EXIT_SUCCESS);
    }
  }
  while (dir.next_dir != 0);
  dir.next_dir = sizeof(dir);
  lseek(fd, -sizeof(dir), SEEK_CUR);
  write(fd, &dir, sizeof(dir));
  bzero(dir.pathname, 64);
  memcpy(&dir.pathname[0], pathname, strlen(pathname));
  dir.next_dir = 0;
  dir.first_file = 0;
  write(fd, &dir, sizeof(dir));
}

int       add_subdir(int fd, t_dir dir, char *part, const char *pathname)
{
  char    **tmp;

  do
  {
    tmp = my_str_to_wordtab(dir.pathname, SLASH);
    if (read(fd, &dir, sizeof(dir)) == sizeof(dir))
    {
      if (strcmp(tmp[tablen(tmp) - 1], part) == 0)
      {
        if (dir.sub_dir != 0)
          lseek(fd, -sizeof(dir) + dir.sub_dir, SEEK_CUR);
      }
      else if (dir.next_dir != 0)
        lseek(fd, -sizeof(dir) + dir.next_dir, SEEK_CUR);
    }
    else
    {
      puts("Pathename incorrect.");
      return (EXIT_SUCCESS);
    }
    free_tab(tmp);
  }
  while (dir.next_dir != 0);
}

int       my_mkdir(const char *pathname, mode_t mode, int fd)
{
  t_dir   dir;
  char    **tmp;
  char    **tmp2;
  int     i;
  int     f;

  bzero(dir.pathname, 64);
  lseek(fd, sizeof(t_hd), SEEK_SET);
  tmp = my_str_to_wordtab(pathname, SLASH);
  i = 0;
  if (tablen(tmp) == 1)
    add_dir(fd, dir, pathname);
  else {
    if(read(fd, &dir, sizeof(dir)) != sizeof(dir))
    {
      puts("Pathename incorrect.");
      return (EXIT_SUCCESS);
    }
    while (tmp[i + 1])
    {
      f = 0;
      while (dir.next_dir != 0)
      {
        tmp2 = my_str_to_wordtab(dir.pathname, SLASH);
        if (strcmp(tmp2[tablen(tmp2) - 1], tmp[i]) == 0)
        {
            if (dir.sub_dir != 0)
            {
              lseek(fd, -sizeof(dir) + dir.sub_dir, SEEK_CUR);
              f = 1;
            }
            if (dir.sub_dir == 0 && tmp[i + 2])
              break;
            if (dir.next_dir != 0)
              lseek(fd, -sizeof(dir) + dir.next_dir, SEEK_CUR);
        }
        free_tab(tmp2);
      }
      if (f == 0)
      {
        puts("Pathename incorrect.");
        return (EXIT_SUCCESS);
      }
      i++;
    }
    dir.sub_dir = sizeof(dir);
    lseek(fd, -sizeof(dir), SEEK_CUR);
    write(fd, &dir, sizeof(dir));
    bzero(dir.pathname, 64);
    memcpy(&dir.pathname[0], pathname, strlen(pathname));
    dir.next_dir = 0;
    dir.first_file = 0;
    write(fd, &dir, sizeof(dir));  
  }
}