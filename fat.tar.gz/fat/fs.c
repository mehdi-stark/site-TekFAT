// Ilyas Zelloufi "Damdoshi"
// 

#include 		"fs.h"

void        setharddrivefile(const char *f, size_t size)
{
	int       fd;

  if(access(f, F_OK) == -1) 
  {
    memcpy(&hd.harddrive_path[0], f, strlen(f));
    hd.size = size;
    hd.mem_used = 0;
    hd.fd = open(f, O_RDWR | O_CREAT, 0644);
    write(hd.fd, &hd, sizeof(hd));
  }
  else 
  {
    fd = open(f, O_RDWR, 0644);
    if (read(fd, &hd, sizeof(hd)) != sizeof(hd))
      my_exit ("File exist but doesn't have harddrive params.");
    hd.fd = fd;
  }
}

int         my_ls(int fd)
{
  t_dir     dir;
  int      c;

  lseek(fd, sizeof(t_hd), SEEK_SET);
  while ((c = read(fd, &dir, sizeof(dir))) == sizeof(dir))
  {
    printf("%s\n", &dir.pathname[0]);
    if (dir.next_dir != 0)
      lseek(fd, -sizeof(dir) + dir.next_dir, SEEK_CUR);
    else
    {
      close(fd);
      return (EXIT_SUCCESS);
    }
  }
}

int         main(int    argc, char    **argv)
{ 
  int fd;

  setharddrivefile("toto", 100);
  mk("izi", 0, hd.fd);
  mk("uzi", 0, hd.fd);
  my_ls(hd.fd);
  close(hd.fd);
  return (EXIT_SUCCESS);
}


