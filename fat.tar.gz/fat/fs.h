#ifndef		                   _FS_H__
# define	                   _FS_H__
# include                    <string.h>
# include                    <stdlib.h>
# include                    <unistd.h>
# include                    <fcntl.h>
# include                    <stdio.h>
# define                     DEFAULT_SIZE  100000000
# define                     DEFAULT_PATH  "./default_harddrive_file"
# define                     NB_FD         20

# if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
    #  define                SLASH           '\\'
# else
    #  define                SLASH           '/'
# endif

typedef struct		            s_dir
{
  char			                  pathname[64];
  int			                    next_dir;
  int			                    first_file;
  int                         sub_dir;
}			                        t_dir;

typedef struct                s_harddrive
{
  char                        harddrive_path[64];
  int                         size;
  int                         mem_used;
  int                         fd;
}                             t_hd;

t_hd                          hd;

void                          setharddrivefile(const char *f, size_t size);
int                           my_ls(int fd);
int                           mkdir(const char *pathname, mode_t mode);
int                           count_word(const char *str, char separe);
char                          **my_str_to_wordtab(const char *str, char separe);
void                          my_exit(char *str);
int                           firstdir(t_dir *dir, char *pathname, int fd);
int                           subdir(char *pathname, t_dir *dir, int *fd);

#endif				/* _FS_H_ */